/* Emergency Response frontend: vanilla JS, same-origin Flask API. */
const API = {
  stats: "/api/dashboard/stats",
  incidents: "/api/incidents",
  incident: id => `/api/incidents/${encodeURIComponent(id)}`
};
const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
let incidents = [];
let currentIncident = null;

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function pick(obj, ...keys) { for (const key of keys) if (obj && obj[key] !== undefined && obj[key] !== null) return obj[key]; return ""; }
function idOf(x){return pick(x,"id","incident_id","incidentId");}
function titleOf(x){return pick(x,"title","name") || `Incident #${idOf(x)}`;}
function categoryOf(x){return pick(x,"category","type") || "Uncategorized";}
function locationOf(x){return pick(x,"location","address","place") || "Location not provided";}
function statusOf(x){return pick(x,"status") || "Reported";}
function severityOf(x){return String(pick(x,"severity","priority_level") || "Unknown");}
function scoreOf(x){return pick(x,"priority_score","priority","score");}
function dateOf(x){return pick(x,"created_at","reported_at","timestamp","date") || "—";}
function severityClass(v){const s=String(v).toLowerCase();return s.includes("critical")?"critical":s.includes("high")?"high":s.includes("medium")?"medium":s.includes("low")?"low":"";}
function severityBadge(v){return `<span class="badge badge-${severityClass(v)}">${escapeHTML(v || "Unknown")}</span>`;}
function statusBadge(v){return `<span class="badge badge-status">${escapeHTML(v)}</span>`;}
function formatDate(v){if(!v || v==="—")return "—";const d=new Date(v);return Number.isNaN(d.getTime())?escapeHTML(v):d.toLocaleString();}
async function api(url, options={}) {
  const response = await fetch(url, {headers:{"Accept":"application/json",...(options.body?{"Content-Type":"application/json"}:{})},...options});
  let data={};try{data=await response.json();}catch{}
  if(!response.ok) throw new Error(data.message || data.error || `Request failed (${response.status})`);
  return data;
}
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),3200);}
function setApiState(ok){const el=$("#apiState");el.classList.toggle("connected",ok);el.innerHTML=`<i></i> ${ok?"API connected":"API unavailable"}`;}
function showView(name){
  const valid=["dashboard","incidents","report","track","map","details"];
  if(!valid.includes(name))name="dashboard";
  $$(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${name}`));
  $$(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
  $("#pageCrumb").textContent=({dashboard:"Dashboard",incidents:"Incident Management",report:"Report Emergency",track:"Incident Tracking",map:"Emergency Map",details:"Incident Details"})[name];
  $("#sidebar").classList.remove("open");
  if(name==="dashboard") refreshDashboard();
  if(name==="incidents") renderIncidentTable();
  if(name==="map") renderMap();
}
document.addEventListener("click",e=>{
  const target=e.target.closest("[data-view]");if(target)showView(target.dataset.view);
  const action=e.target.closest("[data-action]");if(action){const id=action.dataset.id;if(action.dataset.action==="view")openDetails(id);if(action.dataset.action==="delete")deleteIncident(id);}
});
$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));

async function refreshDashboard(){
  try{
    const [statsData, listData]=await Promise.all([api(API.stats),api(API.incidents)]);
    setApiState(true);
    const stats=statsData.stats || statsData;
    incidents=Array.isArray(listData)?listData:(listData.incidents||listData.data||[]);
    $("#statTotal").textContent=pick(stats,"total_incidents","total","totalIncidents")??"—";
    $("#statCritical").textContent=pick(stats,"critical_incidents","critical","criticalIncidents")??"—";
    $("#statPending").textContent=pick(stats,"pending_incidents","pending","pendingIncidents")??"—";
    $("#statResolved").textContent=pick(stats,"resolved_incidents","resolved","resolvedIncidents")??"—";
    renderDistribution($("#categoryChart"),pick(stats,"category_distribution","categories")||{},false);
    renderDistribution($("#severityChart"),pick(stats,"severity_distribution","severities")||{},true);
    renderRecent();renderPriority();renderMapMarkers($("#miniMap"));
  }catch(err){setApiState(false);showErrorRows(err);toast(err.message);}
}
function showErrorRows(err){$("#recentTable").innerHTML=`<tr><td colspan="6" class="empty">${escapeHTML(err.message)}. Check Flask is running.</td></tr>`;$("#categoryChart").innerHTML=`<p class="empty">${escapeHTML(err.message)}</p>`;$("#severityChart").innerHTML=`<p class="empty">${escapeHTML(err.message)}</p>`;}
function distributionEntries(data){
  if(Array.isArray(data))return data.map(x=>[pick(x,"category","severity","name","label")||"Other",Number(pick(x,"count","total","value")||0)]);
  return Object.entries(data||{}).map(([k,v])=>[k,Number(typeof v==="object"?pick(v,"count","total","value")||0:v)||0]);
}
function renderDistribution(el,data,severity){
  const entries=distributionEntries(data).sort((a,b)=>b[1]-a[1]);const max=Math.max(1,...entries.map(x=>x[1]));
  if(!entries.length){el.innerHTML='<p class="empty">No distribution data available.</p>';return;}
  if(severity){el.innerHTML=entries.map(([name,count])=>`<div class="severity-row"><span><i class="dot ${severityClass(name)}"></i>${escapeHTML(name)}</span><strong>${count}</strong></div>`).join("");}
  else el.innerHTML=entries.slice(0,8).map(([name,count])=>`<div class="dist-row"><span>${escapeHTML(name)}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.max(0,count/max*100)}%"></div></div><span class="dist-count">${count}</span></div>`).join("");
}
function renderRecent(){
 const rows=[...incidents].sort((a,b)=>new Date(dateOf(b))-new Date(dateOf(a))).slice(0,6);
 $("#recentTable").innerHTML=rows.length?rows.map(x=>`<tr><td><span class="incident-title">#${escapeHTML(idOf(x))} ${escapeHTML(titleOf(x))}</span></td><td>${escapeHTML(categoryOf(x))}</td><td>${escapeHTML(locationOf(x))}</td><td>${severityBadge(severityOf(x))}</td><td>${statusBadge(statusOf(x))}</td><td><button class="small-btn" data-action="view" data-id="${escapeHTML(idOf(x))}">View</button></td></tr>`).join(""):'<tr><td colspan="6" class="empty">No incidents reported yet.</td></tr>';
}
function renderPriority(){
 const active=incidents.filter(x=>!String(statusOf(x)).toLowerCase().includes("resolved")).sort((a,b)=>Number(scoreOf(b)||0)-Number(scoreOf(a)||0)).slice(0,4);
 $("#priorityList").innerHTML=active.length?active.map(x=>`<div class="priority-item"><div><strong>#${escapeHTML(idOf(x))} ${escapeHTML(titleOf(x))}</strong><small>${escapeHTML(locationOf(x))} · ${escapeHTML(severityOf(x))}</small></div><span class="priority-score">${escapeHTML(scoreOf(x)||"—")}</span></div>`).join(""):'<p class="empty">No active incidents.</p>';
}
function renderIncidentTable(){
 const q=($("#incidentSearch")?.value||"").toLowerCase(),cat=$("#filterCategory")?.value||"",sev=$("#filterSeverity")?.value||"",stat=$("#filterStatus")?.value||"";
 const rows=incidents.filter(x=>(`${idOf(x)} ${titleOf(x)} ${locationOf(x)}`.toLowerCase().includes(q))&&(!cat||categoryOf(x)===cat)&&(!sev||severityOf(x).toLowerCase()===sev.toLowerCase())&&(!stat||statusOf(x).toLowerCase()===stat.toLowerCase())).sort((a,b)=>Number(scoreOf(b)||0)-Number(scoreOf(a)||0));
 $("#incidentTable").innerHTML=rows.length?rows.map(x=>`<tr><td>#${escapeHTML(idOf(x))}</td><td><span class="incident-title">${escapeHTML(titleOf(x))}</span></td><td>${escapeHTML(categoryOf(x))}</td><td>${escapeHTML(locationOf(x))}</td><td>${severityBadge(severityOf(x))}</td><td>${escapeHTML(scoreOf(x)||"—")}</td><td>${statusBadge(statusOf(x))}</td><td>${formatDate(dateOf(x))}</td><td><div class="row-actions"><button class="small-btn" data-action="view" data-id="${escapeHTML(idOf(x))}">View</button><button class="small-btn delete" data-action="delete" data-id="${escapeHTML(idOf(x))}">Delete</button></div></td></tr>`).join(""):'<tr><td colspan="9" class="empty">No matching incidents found.</td></tr>';
 $("#incidentCount").textContent=`Showing ${rows.length} of ${incidents.length} incidents`;
 const select=$("#filterCategory");if(select&&select.options.length===1){[...new Set(incidents.map(categoryOf))].sort().forEach(c=>select.add(new Option(c,c)));}
}
async function loadIncidents(){
 try{const data=await api(API.incidents);incidents=Array.isArray(data)?data:(data.incidents||data.data||[]);setApiState(true);renderIncidentTable();renderRecent();renderPriority();renderMap();}catch(e){setApiState(false);$("#incidentTable").innerHTML=`<tr><td colspan="9" class="empty">${escapeHTML(e.message)}</td></tr>`;toast(e.message);}
}
async function submitReport(e){
 e.preventDefault();const form=e.currentTarget,button=$("#submitReport"),feedback=$("#reportFeedback");button.disabled=true;button.textContent="Submitting…";feedback.hidden=true;
 const fd=new FormData(form),payload={title:fd.get("title").trim(),description:fd.get("description").trim(),category:fd.get("category"),location:fd.get("location").trim(),people_affected:Number(fd.get("people_affected")||0),contact_number:fd.get("contact_number").trim()||null,immediate_danger:fd.has("immediate_danger"),latitude:fd.get("latitude")?Number(fd.get("latitude")):null,longitude:fd.get("longitude")?Number(fd.get("longitude")):null};
 try{const data=await api(API.incidents,{method:"POST",body:JSON.stringify(payload)});const item=data.incident||data;feedback.className="feedback success";feedback.innerHTML=`Incident submitted successfully. <strong>Incident ID: #${escapeHTML(idOf(item)||"created")}</strong>${item.severity?` · Severity: ${escapeHTML(item.severity)}`:""}`;feedback.hidden=false;form.reset();toast("Emergency report submitted");await loadIncidents();showView("incidents");}catch(err){feedback.className="feedback error";feedback.textContent=err.message;feedback.hidden=false;toast(err.message);}finally{button.disabled=false;button.textContent="Submit Emergency Report →";}
}
async function openDetails(id){
 try{const data=await api(API.incident(id));currentIncident=data.incident||data;renderDetails(currentIncident);showView("details");}catch(err){toast(err.message);}
}
function renderDetails(x){
 const id=idOf(x),sev=severityOf(x),status=statusOf(x),timeline=pick(x,"timeline","status_history")||[];
 const stages=["Reported","Pending","In Progress","Resolved"],current=stages.findIndex(s=>s.toLowerCase()===status.toLowerCase());
 $("#detailsContent").innerHTML=`<article class="panel"><div class="panel-heading"><div><p class="eyebrow">INCIDENT #${escapeHTML(id)}</p><h2>${escapeHTML(titleOf(x))}</h2><p class="muted">${escapeHTML(categoryOf(x))} · ${formatDate(dateOf(x))}</p></div>${severityBadge(sev)}</div><div class="details-grid"><div class="detail-box"><label>Location</label><strong>${escapeHTML(locationOf(x))}</strong></div><div class="detail-box"><label>Status</label><strong>${statusBadge(status)}</strong></div><div class="detail-box"><label>Priority score</label><strong>${escapeHTML(scoreOf(x)||"Not provided by API")}</strong></div><div class="detail-box"><label>People affected</label><strong>${escapeHTML(pick(x,"people_affected","affected_count")||0)}</strong></div><div class="detail-box"><label>Coordinates</label><strong>${escapeHTML(pick(x,"latitude","lat")||"—")}, ${escapeHTML(pick(x,"longitude","lng","lon")||"—")}</strong></div><div class="detail-box"><label>Immediate danger</label><strong>${pick(x,"immediate_danger")===true?"Yes":"Not indicated"}</strong></div><div class="detail-box details-description"><label>Description</label><strong>${escapeHTML(pick(x,"description")||"No description provided")}</strong></div></div><h2 style="margin-top:22px">Response timeline</h2><div class="timeline">${stages.map((s,i)=>`<div class="timeline-step ${i<current?"done":i===current?"current":""}">${escapeHTML(s)}</div>`).join("")}</div>${timeline.length?`<div>${timeline.map(t=>`<p class="subtext">${escapeHTML(pick(t,"status","event")||"Update")} · ${formatDate(pick(t,"created_at","timestamp","updated_at"))}</p>`).join("")}</div>`:""}<form class="status-update" id="statusUpdate"><select name="status" aria-label="New status">${stages.map(s=>`<option ${s.toLowerCase()===status.toLowerCase()?"selected":""}>${s}</option>`).join("")}</select><button class="btn primary">Update Status</button></form></article>`;
 $("#statusUpdate").addEventListener("submit",async e=>{e.preventDefault();const next=new FormData(e.currentTarget).get("status");try{await api(API.incident(id),{method:"PUT",body:JSON.stringify({status:next})});toast("Incident status updated");await loadIncidents();openDetails(id);}catch(err){toast(err.message);}});
}
async function deleteIncident(id){if(!confirm(`Delete incident #${id}? This cannot be undone.`))return;try{await api(API.incident(id),{method:"DELETE"});toast("Incident deleted");await loadIncidents();}catch(err){toast(err.message);}}
function renderMapMarkers(container){
 container.querySelectorAll(".map-marker").forEach(n=>n.remove());const withCoords=incidents.filter(x=>Number.isFinite(Number(pick(x,"latitude","lat")))&&Number.isFinite(Number(pick(x,"longitude","lng","lon"))));
 withCoords.forEach((x,i)=>{const marker=document.createElement("button");marker.className=`map-marker ${severityClass(severityOf(x))}`;marker.title=`#${idOf(x)} ${titleOf(x)}`;marker.setAttribute("aria-label",marker.title);const lat=Number(pick(x,"latitude","lat")),lon=Number(pick(x,"longitude","lng","lon"));marker.style.left=`${12+((Math.abs(lon*13.7+i*17)%76))}%`;marker.style.top=`${15+((Math.abs(lat*9.3+i*23)%70))}%`;marker.addEventListener("click",()=>openDetails(idOf(x)));container.append(marker);});
 const msg=container.querySelector(".map-empty");if(msg)msg.textContent=withCoords.length?`${withCoords.length} incident marker(s). Select a marker to open details.`:"No incidents with coordinates available.";
}
function renderMap(){
 renderMapMarkers($("#fullMap"));const list=$("#mapIncidentList");list.innerHTML=incidents.length?incidents.slice(0,20).map(x=>`<div class="map-incident" data-action="view" data-id="${escapeHTML(idOf(x))}"><strong>#${escapeHTML(idOf(x))} ${escapeHTML(titleOf(x))}</strong><small>${escapeHTML(locationOf(x))} · ${escapeHTML(severityOf(x))}</small></div>`).join(""):'<p class="empty">No incidents reported.</p>';
}
$("#reportForm").addEventListener("submit",submitReport);
$("#trackForm").addEventListener("submit",async e=>{e.preventDefault();const id=new FormData(e.currentTarget).get("incidentId").trim();$("#trackingResult").innerHTML='<p class="empty">Searching…</p>';try{const data=await api(API.incident(id)),x=data.incident||data;const stages=["Reported","Pending","In Progress","Resolved"],cur=stages.findIndex(s=>s.toLowerCase()===statusOf(x).toLowerCase());$("#trackingResult").innerHTML=`<div class="track-result"><p class="eyebrow">INCIDENT #${escapeHTML(idOf(x))}</p><h2>${escapeHTML(titleOf(x))}</h2><p class="muted">${escapeHTML(locationOf(x))} · ${formatDate(dateOf(x))}</p><p style="margin-top:12px">${statusBadge(statusOf(x))} ${severityBadge(severityOf(x))}</p><div class="timeline">${stages.map((s,i)=>`<div class="timeline-step ${i<cur?"done":i===cur?"current":""}">${escapeHTML(s)}</div>`).join("")}</div><p>${escapeHTML(pick(x,"description")||"No description supplied.")}</p></div>`;}catch(err){$("#trackingResult").innerHTML=`<p class="feedback error">${escapeHTML(err.message)}</p>`;}});
$("#incidentSearch").addEventListener("input",renderIncidentTable);["filterCategory","filterSeverity","filterStatus"].forEach(id=>$("#"+id).addEventListener("change",renderIncidentTable));
$("#refreshIncidents").addEventListener("click",loadIncidents);$("#refreshMap").addEventListener("click",loadIncidents);
(async()=>{await loadIncidents();await refreshDashboard();})();
