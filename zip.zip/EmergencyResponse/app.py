import math
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, g, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DATABASE_PATH = os.environ.get(
    "EMERGENCY_DB_PATH", str(BASE_DIR / "emergency_response.db")
)

CATEGORIES = [
    "Fire Emergency",
    "Road Accident",
    "Medical Emergency",
    "Flood",
    "Building Collapse",
    "Other Emergencies",
]

CATEGORY_POINTS = {
    "Fire Emergency": 20,
    "Road Accident": 15,
    "Medical Emergency": 20,
    "Flood": 15,
    "Building Collapse": 25,
    "Other Emergencies": 10,
}

STATUSES = ["Reported", "Pending", "In Progress", "Resolved"]

SEVERITIES = ["Low", "Medium", "High", "Critical"]

app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="/static")


class ValidationError(Exception):
    def __init__(self, message, details=None):
        super().__init__(message)
        self.message = message
        self.details = details


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def connect_db():
    connection = sqlite3.connect(DATABASE_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def get_db():
    if "db" not in g:
        g.db = connect_db()
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    connection = connect_db()
    try:
        connection.execute("PRAGMA journal_mode = WAL")
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS incidents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                category TEXT NOT NULL,
                location TEXT NOT NULL,
                latitude REAL,
                longitude REAL,
                people_affected INTEGER NOT NULL DEFAULT 0,
                contact TEXT,
                immediate_danger INTEGER NOT NULL DEFAULT 0,
                priority_score INTEGER NOT NULL,
                severity TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Reported',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS incident_timeline (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                incident_id INTEGER NOT NULL,
                status TEXT NOT NULL,
                previous_status TEXT,
                note TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (incident_id) REFERENCES incidents (id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_incidents_category
                ON incidents (category);
            CREATE INDEX IF NOT EXISTS idx_incidents_status
                ON incidents (status);
            CREATE INDEX IF NOT EXISTS idx_incidents_severity
                ON incidents (severity);
            CREATE INDEX IF NOT EXISTS idx_incidents_created_at
                ON incidents (created_at);
            CREATE INDEX IF NOT EXISTS idx_timeline_incident_id
                ON incident_timeline (incident_id);
            """
        )
        connection.commit()
    finally:
        connection.close()


def calculate_priority(category, people_affected, immediate_danger):
    category_score = CATEGORY_POINTS[category]

    if people_affected <= 0:
        people_score = 0
    elif people_affected <= 5:
        people_score = 5
    elif people_affected <= 20:
        people_score = 10
    else:
        people_score = 20

    danger_score = 20 if immediate_danger else 0
    return category_score + people_score + danger_score


def calculate_severity(priority_score):
    if priority_score <= 24:
        return "Low"
    if priority_score <= 44:
        return "Medium"
    if priority_score <= 64:
        return "High"
    return "Critical"


def incident_to_dict(row):
    incident = dict(row)
    incident["immediate_danger"] = bool(incident["immediate_danger"])
    return incident


def timeline_to_dict(row):
    return dict(row)


def require_json_body():
    body = request.get_json(silent=True)
    if body is None:
        raise ValidationError(
            "Request body must be valid JSON. Set Content-Type to application/json."
        )
    if not isinstance(body, dict):
        raise ValidationError("Request body must be a JSON object.")
    return body


def parse_required_string(body, field, max_length):
    value = body.get(field)
    if value is None:
        raise ValidationError(f"'{field}' is required.")
    if not isinstance(value, str):
        raise ValidationError(f"'{field}' must be a string.")
    value = value.strip()
    if not value:
        raise ValidationError(f"'{field}' cannot be empty.")
    if len(value) > max_length:
        raise ValidationError(f"'{field}' must be {max_length} characters or fewer.")
    return value


def parse_optional_string(body, field, max_length):
    value = body.get(field)
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        value = str(value)
    if not isinstance(value, str):
        raise ValidationError(f"'{field}' must be a string.")
    value = value.strip()
    if not value:
        return None
    if len(value) > max_length:
        raise ValidationError(f"'{field}' must be {max_length} characters or fewer.")
    return value


def parse_category(body, default=None):
    value = body.get("category", default)
    if value is None:
        raise ValidationError("'category' is required.")
    if value not in CATEGORIES:
        raise ValidationError(
            "'category' must be one of the supported values.",
            {"allowed_values": CATEGORIES},
        )
    return value


def parse_status(body, default=None):
    value = body.get("status", default)
    if value is None:
        raise ValidationError("'status' is required.")
    if value not in STATUSES:
        raise ValidationError(
            "'status' must be one of the supported values.",
            {"allowed_values": STATUSES},
        )
    return value


def parse_people_affected(body, default=None):
    if "people_affected" not in body:
        if default is None:
            raise ValidationError("'people_affected' is required.")
        return default

    value = body.get("people_affected")
    if isinstance(value, bool) or value is None:
        raise ValidationError("'people_affected' must be a non-negative integer.")

    if isinstance(value, int):
        number = value
    elif isinstance(value, float):
        if not value.is_integer():
            raise ValidationError("'people_affected' must be a whole number.")
        number = int(value)
    elif isinstance(value, str):
        text = value.strip()
        if not text:
            raise ValidationError("'people_affected' cannot be empty.")
        try:
            number = int(text)
        except ValueError:
            raise ValidationError("'people_affected' must be a non-negative integer.")
    else:
        raise ValidationError("'people_affected' must be a non-negative integer.")

    if number < 0:
        raise ValidationError("'people_affected' cannot be negative.")
    return number


def parse_immediate_danger(body, default=False):
    if "immediate_danger" not in body:
        return default

    value = body.get("immediate_danger")
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in ("true", "yes", "1", "y"):
            return True
        if text in ("false", "no", "0", "n"):
            return False
    raise ValidationError("'immediate_danger' must be true or false.")


def parse_coordinate(body, field, minimum, maximum):
    value = body.get(field)
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValidationError(f"'{field}' must be a number.")
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            value = float(text)
        except ValueError:
            raise ValidationError(f"'{field}' must be a number.")
    elif not isinstance(value, (int, float)):
        raise ValidationError(f"'{field}' must be a number.")

    value = float(value)
    if not math.isfinite(value):
        raise ValidationError(f"'{field}' must be a finite number.")
    if value < minimum or value > maximum:
        raise ValidationError(
            f"'{field}' must be between {minimum} and {maximum}."
        )
    return value


def find_duplicates(category, location, exclude_id=None):
    db = get_db()
    if exclude_id is None:
        rows = db.execute(
            "SELECT id, title, location, status, created_at FROM incidents "
            "WHERE LOWER(category) = LOWER(?)",
            (category,),
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT id, title, location, status, created_at FROM incidents "
            "WHERE LOWER(category) = LOWER(?) AND id != ?",
            (category, exclude_id),
        ).fetchall()

    normalized_location = " ".join(location.lower().split())
    matches = []
    for row in rows:
        existing_location = " ".join((row["location"] or "").lower().split())
        if (
            normalized_location
            and existing_location
            and (
                normalized_location == existing_location
                or normalized_location in existing_location
                or existing_location in normalized_location
            )
        ):
            matches.append(
                {
                    "id": row["id"],
                    "title": row["title"],
                    "location": row["location"],
                    "status": row["status"],
                    "created_at": row["created_at"],
                }
            )
    return matches


def fetch_incident(incident_id):
    return get_db().execute(
        "SELECT * FROM incidents WHERE id = ?", (incident_id,)
    ).fetchone()


def fetch_timeline(incident_id):
    return get_db().execute(
        "SELECT * FROM incident_timeline WHERE incident_id = ? "
        "ORDER BY id ASC",
        (incident_id,),
    ).fetchall()


def add_timeline_entry(incident_id, status, previous_status, note):
    get_db().execute(
        "INSERT INTO incident_timeline "
        "(incident_id, status, previous_status, note, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (incident_id, status, previous_status, note, now_iso()),
    )


@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = (
        "GET, POST, PUT, DELETE, OPTIONS"
    )
    return response


@app.errorhandler(ValidationError)
def handle_validation_error(error):
    payload = {"error": error.message}
    if error.details:
        payload["details"] = error.details
    return jsonify(payload), 400


@app.errorhandler(404)
def handle_not_found(error):
    return jsonify({"error": "Resource not found."}), 404


@app.errorhandler(405)
def handle_method_not_allowed(error):
    return jsonify({"error": "Method not allowed for this endpoint."}), 405


@app.errorhandler(500)
def handle_server_error(error):
    return jsonify({"error": "Internal server error."}), 500


@app.get("/")
def serve_frontend():
    index_file = STATIC_DIR / "index.html"
    if index_file.is_file():
        return send_from_directory(str(STATIC_DIR), "index.html")

    return jsonify(
        {
            "message": "Emergency Response API is running.",
            "frontend": (
                "Place index.html, style.css and script.js in the static folder."
            ),
            "endpoints": [
                "POST /api/incidents",
                "GET /api/incidents",
                "GET /api/incidents/<id>",
                "PUT /api/incidents/<id>",
                "DELETE /api/incidents/<id>",
                "GET /api/dashboard/stats",
            ],
        }
    )


@app.post("/api/incidents")
def create_incident():
    body = require_json_body()

    title = parse_required_string(body, "title", 200)
    description = parse_required_string(body, "description", 5000)
    category = parse_category(body)
    location = parse_required_string(body, "location", 300)
    latitude = parse_coordinate(body, "latitude", -90, 90)
    longitude = parse_coordinate(body, "longitude", -180, 180)
    people_affected = parse_people_affected(body)
    contact = parse_optional_string(body, "contact", 200)
    immediate_danger = parse_immediate_danger(body)
    status = parse_status(body, default="Reported")

    priority_score = calculate_priority(
        category, people_affected, immediate_danger
    )
    severity = calculate_severity(priority_score)
    timestamp = now_iso()

    duplicates = find_duplicates(category, location)

    db = get_db()
    cursor = db.execute(
        "INSERT INTO incidents ("
        "title, description, category, location, latitude, longitude, "
        "people_affected, contact, immediate_danger, priority_score, severity, "
        "status, created_at, updated_at"
        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            title,
            description,
            category,
            location,
            latitude,
            longitude,
            people_affected,
            contact,
            int(immediate_danger),
            priority_score,
            severity,
            status,
            timestamp,
            timestamp,
        ),
    )
    incident_id = cursor.lastrowid
    add_timeline_entry(
        incident_id,
        status,
        None,
        f"Incident reported with status '{status}'.",
    )
    db.commit()

    incident = incident_to_dict(fetch_incident(incident_id))
    matching_ids = [match["id"] for match in duplicates]

    return (
        jsonify(
            {
                "message": "Incident created successfully.",
                "incident": incident,
                "duplicate_warning": bool(duplicates),
                "duplicate_incident_ids": matching_ids,
                "duplicate_matches": duplicates,
            }
        ),
        201,
    )


@app.get("/api/incidents")
def list_incidents():
    conditions = []
    parameters = []

    filters = [
        ("category", CATEGORIES, "category"),
        ("status", STATUSES, "status"),
        ("severity", SEVERITIES, "severity"),
    ]
    for query_name, allowed_values, column in filters:
        value = request.args.get(query_name)
        if value is not None:
            if value not in allowed_values:
                raise ValidationError(
                    f"Invalid '{query_name}' filter.",
                    {"allowed_values": allowed_values},
                )
            conditions.append(f"{column} = ?")
            parameters.append(value)

    search = request.args.get("search")
    if search is not None and search.strip():
        pattern = f"%{search.strip()}%"
        conditions.append(
            "(title LIKE ? OR description LIKE ? OR location LIKE ? OR category LIKE ?)"
        )
        parameters.extend([pattern, pattern, pattern, pattern])

    query = "SELECT * FROM incidents"
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY created_at DESC, id DESC"

    rows = get_db().execute(query, parameters).fetchall()
    incidents = [incident_to_dict(row) for row in rows]

    return jsonify({"count": len(incidents), "incidents": incidents}), 200


@app.get("/api/incidents/<int:incident_id>")
def get_incident(incident_id):
    row = fetch_incident(incident_id)
    if row is None:
        return jsonify({"error": f"Incident {incident_id} was not found."}), 404

    timeline = [timeline_to_dict(item) for item in fetch_timeline(incident_id)]
    return (
        jsonify({"incident": incident_to_dict(row), "timeline": timeline}),
        200,
    )


@app.put("/api/incidents/<int:incident_id>")
def update_incident(incident_id):
    existing = fetch_incident(incident_id)
    if existing is None:
        return jsonify({"error": f"Incident {incident_id} was not found."}), 404

    body = require_json_body()
    current = incident_to_dict(existing)
    updates = {}
    status_changed = False

    if "title" in body:
        updates["title"] = parse_required_string(body, "title", 200)
    if "description" in body:
        updates["description"] = parse_required_string(body, "description", 5000)
    if "category" in body:
        updates["category"] = parse_category(body)
    if "location" in body:
        updates["location"] = parse_required_string(body, "location", 300)
    if "latitude" in body:
        updates["latitude"] = parse_coordinate(body, "latitude", -90, 90)
    if "longitude" in body:
        updates["longitude"] = parse_coordinate(body, "longitude", -180, 180)
    if "people_affected" in body:
        updates["people_affected"] = parse_people_affected(body)
    if "contact" in body:
        updates["contact"] = parse_optional_string(body, "contact", 200)
    if "immediate_danger" in body:
        updates["immediate_danger"] = int(
            parse_immediate_danger(body, default=current["immediate_danger"])
        )
    if "status" in body:
        new_status = parse_status(body)
        if new_status != current["status"]:
            status_changed = True
        updates["status"] = new_status

    if not updates:
        raise ValidationError(
            "No valid fields were provided for update.",
            {
                "updatable_fields": [
                    "title",
                    "description",
                    "category",
                    "location",
                    "latitude",
                    "longitude",
                    "people_affected",
                    "contact",
                    "immediate_danger",
                    "status",
                ]
            },
        )

    merged_category = updates.get("category", current["category"])
    merged_people = updates.get("people_affected", current["people_affected"])
    merged_danger = bool(
        updates.get("immediate_danger", int(current["immediate_danger"]))
    )

    priority_score = calculate_priority(
        merged_category, merged_people, merged_danger
    )
    severity = calculate_severity(priority_score)

    updates["priority_score"] = priority_score
    updates["severity"] = severity
    updates["updated_at"] = now_iso()

    assignments = ", ".join(f"{column} = ?" for column in updates)
    parameters = list(updates.values()) + [incident_id]

    db = get_db()
    db.execute(
        f"UPDATE incidents SET {assignments} WHERE id = ?", parameters
    )

    if status_changed:
        add_timeline_entry(
            incident_id,
            updates["status"],
            current["status"],
            (
                f"Status changed from '{current['status']}' "
                f"to '{updates['status']}'."
            ),
        )

    db.commit()

    incident = incident_to_dict(fetch_incident(incident_id))
    return (
        jsonify(
            {
                "message": "Incident updated successfully.",
                "incident": incident,
            }
        ),
        200,
    )


@app.delete("/api/incidents/<int:incident_id>")
def delete_incident(incident_id):
    existing = fetch_incident(incident_id)
    if existing is None:
        return jsonify({"error": f"Incident {incident_id} was not found."}), 404

    db = get_db()
    db.execute("DELETE FROM incidents WHERE id = ?", (incident_id,))
    db.commit()

    return (
        jsonify(
            {
                "message": "Incident deleted successfully.",
                "deleted_incident_id": incident_id,
            }
        ),
        200,
    )


@app.get("/api/dashboard/stats")
def dashboard_stats():
    db = get_db()

    total_incidents = db.execute(
        "SELECT COUNT(*) FROM incidents"
    ).fetchone()[0]
    critical_incidents = db.execute(
        "SELECT COUNT(*) FROM incidents WHERE severity = 'Critical'"
    ).fetchone()[0]
    pending_incidents = db.execute(
        "SELECT COUNT(*) FROM incidents WHERE status = 'Pending'"
    ).fetchone()[0]
    resolved_incidents = db.execute(
        "SELECT COUNT(*) FROM incidents WHERE status = 'Resolved'"
    ).fetchone()[0]

    incidents_by_category = {category: 0 for category in CATEGORIES}
    for row in db.execute(
        "SELECT category, COUNT(*) AS total FROM incidents GROUP BY category"
    ).fetchall():
        incidents_by_category[row["category"]] = row["total"]

    incidents_by_severity = {severity: 0 for severity in SEVERITIES}
    for row in db.execute(
        "SELECT severity, COUNT(*) AS total FROM incidents GROUP BY severity"
    ).fetchall():
        incidents_by_severity[row["severity"]] = row["total"]

    incidents_by_status = {status: 0 for status in STATUSES}
    for row in db.execute(
        "SELECT status, COUNT(*) AS total FROM incidents GROUP BY status"
    ).fetchall():
        incidents_by_status[row["status"]] = row["total"]

    return (
        jsonify(
            {
                "total_incidents": total_incidents,
                "critical_incidents": critical_incidents,
                "pending_incidents": pending_incidents,
                "resolved_incidents": resolved_incidents,
                "incidents_by_category": incidents_by_category,
                "incidents_by_severity": incidents_by_severity,
                "incidents_by_status": incidents_by_status,
            }
        ),
        200,
    )


init_db()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
